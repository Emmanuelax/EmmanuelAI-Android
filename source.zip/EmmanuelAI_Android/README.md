# Emmanuel AI — Android starter app

A Kotlin Android Studio project for an owner-operated assistant on Android 8+ (targeted/test setup: Android 13 / Infinix Smart 8).

## Included
- Voice input through Android's speech-recognition activity (asks for microphone permission).
- Typed commands.
- Spoken status responses using Android Text-to-Speech.
- Volume up/down.
- Optional accessibility service for Home, Back and Recents. The owner must explicitly enable it in Android Settings.
- Confirmation before launching supported apps or opening the dialer with a number.
- Safe message behavior: it does not silently send SMS or WhatsApp messages.

## Build and install
1. On a computer, install Android Studio (current stable) and the Android SDK.
2. Extract this ZIP and open the `EmmanuelAI_Android` folder in Android Studio.
3. Let Gradle sync and install the required SDK platform if prompted.
4. Connect the phone with USB debugging enabled, or build a debug APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the debug APK on your own phone. If installing directly, Android may ask you to allow that installer to install unknown apps.
6. Open Emmanuel AI and grant microphone permission if you want voice input.
7. Optional: tap **Enable phone navigation** and enable **Emmanuel AI phone actions** in Accessibility settings. Grant this only if you want Home/Back/Recents commands.

## Supported commands
- `help`
- `open WhatsApp` / `open YouTube` / `open Chrome` / `open Settings` / `open Camera` / `open Phone`
- `volume up` / `volume down`
- `go home` / `go back` / `recent apps` (requires optional Accessibility service)
- `call 08012345678` (confirmation opens the dialer; it does not place the call automatically)

## Limitations
- This is a working starter implementation, not a fully conversational AI model. It uses a small local command parser.
- Speech recognition may use Google's speech service or another configured Android provider and may require internet.
- No always-listening hotword; voice input starts when the user taps the button.
- Android does not permit arbitrary silent control of every app. Secure screens, lock-screen bypass, some system settings, and protected apps remain off limits.
- No silent message sending, purchases, payments, or calls. The dialer opens only after confirmation.
- Accessibility permission is powerful. Enable it only after reviewing the code and only for this app.
- The counter, cloud memory, and remote AI model are not included. No commands or transcripts are sent to a server by this starter app.

## Next steps for production
Add an opt-in LLM backend for natural-language understanding, encrypted user settings, clear permission explanations, and automated device testing on the target Infinix device.
