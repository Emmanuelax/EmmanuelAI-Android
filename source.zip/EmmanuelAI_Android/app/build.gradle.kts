plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.emmanuelabu.assistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.emmanuelabu.assistant"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
}
