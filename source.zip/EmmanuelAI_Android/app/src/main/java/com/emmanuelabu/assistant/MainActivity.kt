package com.emmanuelabu.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var commandInput: EditText
    private lateinit var tts: TextToSpeech
    private var pendingCommand: String? = null
    private val audioPermissionRequest = 71
    private val speechRequest = 72

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101114.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "Emmanuel AI"
            textSize = 30f
            setTextColor(0xFFF4F1FF.toInt())
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Your phone assistant"
            textSize = 16f
            setTextColor(0xFFB9A8FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        status = TextView(this).apply {
            text = "Ready. Type a command or tap Speak."
            textSize = 15f
            setTextColor(0xFFE5E3EB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        transcript = TextView(this).apply {
            text = "Try: open WhatsApp, turn volume up, go home, go back, open Settings, or call [number]."
            textSize = 14f
            setTextColor(0xFFB8B7C4.toInt())
            setPadding(0, 8, 0, 16)
        }
        commandInput = EditText(this).apply {
            hint = "Type a command..."
            setHintTextColor(0xFF777782.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            setSingleLine(true)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFF25252D.toInt())
        }
        val speak = makeButton("🎙  Speak a command") { listen() }
        val run = makeButton("Run typed command") { handleCommand(commandInput.text.toString()) }
        val confirm = makeButton("Confirm pending action") { confirmPending() }
        val cancel = makeButton("Cancel pending action") {
            pendingCommand = null
            updateStatus("Action cancelled.")
        }
        val accessibility = makeButton("Enable phone navigation (optional)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val help = TextView(this).apply {
            text = "\nSafety: actions such as opening apps or placing a call ask for confirmation. Emmanuel AI never silently sends messages or bypasses your lock screen. Accessibility permission is optional and is controlled by Android Settings."
            textSize = 12f
            setTextColor(0xFF9998A5.toInt())
            setPadding(0, 20, 0, 8)
        }
        listOf(title, sub, status, transcript, commandInput, speak, run, confirm, cancel, accessibility, help).forEach {
            content.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = if (it is Button) 10 else 4
            })
        }
        scroll.addView(content)
        outer.addView(scroll)
        setContentView(outer)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition isn't available on this phone. Use typed commands.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell Emmanuel AI what to do")
        }
        try {
            startActivityForResult(intent, speechRequest)
        } catch (_: Exception) {
            updateStatus("Couldn't start voice recognition. Try typing your command.")
        }
    }

    @Deprecated("Android speech recognition activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == Activity.RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                commandInput.setText(spoken)
                handleCommand(spoken)
            }
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) {
            updateStatus("Please type or say a command.")
            return
        }
        val c = command.lowercase(Locale.ROOT)
        when {
            c in listOf("help", "what can you do", "commands") ->
                updateStatus("Try: open WhatsApp, open YouTube, open Chrome, open Settings, volume up/down, go home, go back, recent apps, or call [number].")
            c.contains("volume up") || c.contains("turn volume up") || c == "increase volume" -> {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                updateStatus("Media volume increased.")
            }
            c.contains("volume down") || c.contains("turn volume down") || c == "decrease volume" -> {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                updateStatus("Media volume decreased.")
            }
            c in listOf("go home", "home", "press home") -> globalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
            c in listOf("go back", "back", "press back") -> globalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            c in listOf("recent apps", "show recent apps", "open recents") -> globalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            c.startsWith("open ") || c.startsWith("launch ") -> {
                pendingCommand = command
                updateStatus("Confirm opening: ${command.substringAfter(' ').trim()}? Tap Confirm pending action to continue.")
            }
            c.startsWith("call ") -> {
                val number = command.substringAfter(' ').trim()
                if (number.isBlank()) updateStatus("Say: call followed by a phone number.")
                else {
                    pendingCommand = "call:$number"
                    updateStatus("Confirm opening the dialer with $number? No call will be placed automatically.")
                }
            }
            c.startsWith("send ") || c.startsWith("message ") || c.contains("send a message") ->
                updateStatus("For safety, I won't send messages automatically. Open the messaging app and review/send the message yourself.")
            c.contains("turn on accessibility") ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else -> updateStatus("I don't know that command yet. Type or say 'help' to see supported commands.")
        }
    }

    private fun confirmPending() {
        val action = pendingCommand ?: run {
            updateStatus("There is no action waiting for confirmation.")
            return
        }
        pendingCommand = null
        if (action.startsWith("call:")) {
            val number = action.removePrefix("call:")
            val intent = Intent(Intent.ACTION_DIAL).apply { data = android.net.Uri.parse("tel:" + android.net.Uri.encode(number)) }
            startActivitySafely(intent, "Couldn't open the phone dialer.")
            return
        }
        val appName = action.substringAfter(' ').trim().lowercase(Locale.ROOT)
        val packageName = when {
            appName.contains("whatsapp") -> "com.whatsapp"
            appName.contains("youtube") -> "com.google.android.youtube"
            appName.contains("chrome") || appName.contains("browser") -> "com.android.chrome"
            appName.contains("settings") -> "com.android.settings"
            appName.contains("camera") -> "com.android.camera2"
            appName.contains("phone") || appName.contains("dialer") -> "com.google.android.dialer"
            appName.contains("calculator") -> "com.google.android.calculator"
            else -> null
        }
        if (packageName == null) {
            updateStatus("I don't have a launcher mapping for '$appName'. Try WhatsApp, YouTube, Chrome, Settings, Camera, or Phone.")
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch == null) {
            updateStatus("$appName isn't installed or Android doesn't expose it. Try another app.")
            return
        }
        startActivitySafely(launch, "Couldn't open $appName.")
    }

    private fun globalAction(action: Int) {
        val service = AssistantAccessibilityService.instance
        if (service == null) {
            updateStatus("To use Home/Back/Recents, enable Emmanuel AI under Android Settings > Accessibility. Or use your phone's navigation buttons.")
            return
        }
        updateStatus(if (service.runGlobalAction(action)) "Done." else "Android didn't allow that navigation action.")
    }

    private fun startActivitySafely(intent: Intent, failure: String) {
        try {
            startActivity(intent)
            updateStatus("Action started.")
        } catch (_: Exception) {
            updateStatus(failure)
        }
    }

    private fun updateStatus(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "emmanuel-ai-status")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
